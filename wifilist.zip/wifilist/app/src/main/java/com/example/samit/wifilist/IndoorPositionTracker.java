package com.example.samit.wifilist;

/**
 * Created by samit on 6/10/2018.
 */

class PositionTracker {
}
